const express = require('express');
const router = express.Router();
const contratoController = require('../controllers/contratoController');

router.get('/', contratoController.getContratos);
router.post('/', contratoController.createContrato);
router.put('/:id', contratoController.updateContrato);
router.delete('/:id', contratoController.deleteContrato);

module.exports = router;
