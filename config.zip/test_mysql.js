const mysql = require('mysql');

console.log("Módulo MySQL importado com sucesso!");
