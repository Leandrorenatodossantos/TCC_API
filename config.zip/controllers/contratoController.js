const db = require('../config/database');

exports.getContratos = (req, res) => {
    db.query('SELECT * FROM contrato', (err, results) => {
        if (err) res.status(500).json({ error: err });
        else res.json(results);
    });
};

exports.createContrato = (req, res) => {
    const { codigo_contrato, descricao_contrato } = req.body;
    db.query('INSERT INTO contrato (codigo_contrato, descricao_contrato) VALUES (?, ?)',
        [codigo_contrato, descricao_contrato], (err, result) => {
        if (err) res.status(500).json({ error: err });
        else res.json({ message: 'Contrato criado com sucesso!' });
    });
};

exports.updateContrato = (req, res) => {
    const { id } = req.params;
    const { codigo_contrato, descricao_contrato } = req.body;
    db.query('UPDATE contrato SET codigo_contrato = ?, descricao_contrato = ? WHERE id = ?',
        [codigo_contrato, descricao_contrato, id], (err, result) => {
        if (err) res.status(500).json({ error: err });
        else res.json({ message: 'Contrato atualizado com sucesso!' });
    });
};

exports.deleteContrato = (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM contrato WHERE id = ?', [id], (err, result) => {
        if (err) res.status(500).json({ error: err });
        else res.json({ message: 'Contrato deletado com sucesso!' });
    });
};
